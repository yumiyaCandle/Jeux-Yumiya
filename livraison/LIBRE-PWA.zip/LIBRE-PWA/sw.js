/* LIBRE – service worker
   Rôle : rendre l’app utilisable hors ligne après une première visite, et proposer les mises à jour.
   Aucune donnée personnelle ne passe par ici : elles restent dans le stockage local du navigateur.
   À chaque nouvelle version publiée, changer VERSION : l’app propose alors « Mettre à jour ». */
const VERSION='libre-2026-11-26-envol-couleurs-acct';
const CORE=[
 "./",
 "./index.html",
 "./manifest.webmanifest",
 "./privacy.html",
 "./fonts/inter-latin.woff2",
 "./fonts/inter-latin-ext.woff2",
 "./fonts/inter-cyrillic.woff2",
 "./fonts/inter-vietnamese.woff2",
 "./icons/apple-touch-icon.png",
 "./icons/icon-192.png",
 "./icons/icon-512.png",
 "./icons/icon.svg",
 "./icons/maskable-512.png",
 "./photos/aide-1280.avif",
 "./photos/aide-1280.webp",
 "./photos/aide-720.avif",
 "./photos/aide-720.webp",
 "./photos/alcool-1280.avif",
 "./photos/alcool-1280.webp",
 "./photos/alcool-720.avif",
 "./photos/alcool-720.webp",
 "./photos/autres-1280.avif",
 "./photos/autres-1280.webp",
 "./photos/autres-720.avif",
 "./photos/autres-720.webp",
 "./photos/cannabis-1280.avif",
 "./photos/cannabis-1280.webp",
 "./photos/cannabis-720.avif",
 "./photos/cannabis-720.webp",
 "./photos/comprendre-1280.avif",
 "./photos/comprendre-1280.webp",
 "./photos/comprendre-720.avif",
 "./photos/comprendre-720.webp",
 "./photos/corps-1280.avif",
 "./photos/corps-1280.webp",
 "./photos/corps-720.avif",
 "./photos/corps-720.webp",
 "./photos/envies-1280.avif",
 "./photos/envies-1280.webp",
 "./photos/envies-720.avif",
 "./photos/envies-720.webp",
 "./photos/mental-1280.avif",
 "./photos/mental-1280.webp",
 "./photos/mental-720.avif",
 "./photos/mental-720.webp",
 "./photos/motivation-1280.avif",
 "./photos/motivation-1280.webp",
 "./photos/motivation-720.avif",
 "./photos/motivation-720.webp",
 "./photos/plan-1280.avif",
 "./photos/plan-1280.webp",
 "./photos/plan-720.avif",
 "./photos/plan-720.webp",
 "./photos/rechute-1280.avif",
 "./photos/rechute-1280.webp",
 "./photos/rechute-720.avif",
 "./photos/rechute-720.webp",
 "./photos/sevrage-1280.avif",
 "./photos/sevrage-1280.webp",
 "./photos/sevrage-720.avif",
 "./photos/sevrage-720.webp",
 "./photos/sommeil-1280.avif",
 "./photos/sommeil-1280.webp",
 "./photos/sommeil-720.avif",
 "./photos/sommeil-720.webp",
 "./photos/sommet-1280.avif",
 "./photos/sommet-1280.webp",
 "./photos/sommet-720.avif",
 "./photos/sommet-720.webp",
 "./photos/stress-1280.avif",
 "./photos/stress-1280.webp",
 "./photos/stress-720.avif",
 "./photos/stress-720.webp",
 "./photos/tabac-1280.avif",
 "./photos/tabac-1280.webp",
 "./photos/tabac-720.avif",
 "./photos/tabac-720.webp"
];
self.addEventListener('install',e=>{e.waitUntil(caches.open(VERSION).then(c=>c.addAll(CORE)))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==VERSION).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('message',e=>{if(e.data==='skip')self.skipWaiting()});
self.addEventListener('fetch',e=>{const r=e.request,u=new URL(r.url);
  if(r.method!=='GET'||u.origin!==location.origin)return; // rien d’extérieur n’est intercepté
  if(/\/v1\//.test(u.pathname))return; // API de comptes : jamais en cache (données chiffrées, jetons, versions)
  if(r.mode==='navigate'){ // page : réseau d’abord (version la plus récente), sinon la copie locale
    e.respondWith(fetch(r).then(res=>{const c=res.clone();caches.open(VERSION).then(x=>x.put('./index.html',c));return res}).catch(()=>caches.match('./index.html')));return}
  e.respondWith(caches.match(r).then(hit=>hit||fetch(r).then(res=>{if(res.ok&&res.type==='basic'){const c=res.clone();caches.open(VERSION).then(x=>x.put(r,c))}return res})));
});
