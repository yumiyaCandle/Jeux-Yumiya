import UIKit
import Capacitor

/// Contrôleur principal de l’app LIBRE : enregistre le plugin local « LibreHealth ».
/// Dans Main.storyboard, la classe du Bridge View Controller doit être « MainViewController »
/// (module « App »). Voir README.md, étape 5.
class MainViewController: CAPBridgeViewController {
    override open func capacitorDidLoad() {
        bridge?.registerPluginInstance(LibreHealthPlugin())
    }
}
